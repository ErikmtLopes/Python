#leia númeroda conta bancaria e saldo. caso saldo negativo o programa deve informar conta estourada
#caso contrário conta normal.

numeroc = input('Digite o número da conta: ')
saldoc = float(input('Digite o saldo da conta: '))
saldon = 0
if saldoc >= saldon:
    print('Conta número',numeroc,'normal')
else: 
    print('Conta número',numeroc,'estourada')