#Determinar se uma pessoa é maior ou menor de idade

idade = int(input('Digite a sua idade: '))
if idade >= 18:
    print('Você é maior de idade')
else:
    print('Você é menor de idade')